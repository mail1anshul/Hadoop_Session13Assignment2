object FibonacciApp_Loop {

  def fib2( n : Int ) : Int = {
  var a = 0
  var b = 1
  var i = 0	  
 
  while( i < n ) {
    val c = a + b
    a = b
    b = c
    i = i + 1
  } 
  return a
  }
  
  def main(args: Array[String])
  {
    println(fib2(9))
  }
}